# Contact and Fit

Keep contact readiness and brand fit independent.

## Contact readiness

- Officially published business contact plus credible verification: may be usable for later gates.
- Publicly found but not officially published: review first.
- Inferred, guessed, catch-all, unverified or private personal address: do not treat as ready.
- No safe contact: CONTACT_NOT_READY.

Contact readiness is not send authorization.

## Ana/Brand fit

Use at least two qualitative dimensions, for example:
- content/format fit
- audience fit
- values fit
- travel/geography fit
- product use credibility
- commercial plausibility

Do not invent a universal scoring formula. Include the strongest reason the partnership may not work.
