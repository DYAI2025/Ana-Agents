# Evidence Rules

Use exactly four epistemic labels:

- FACT: directly supported by a source.
- SUPPORTED_INFERENCE: a grounded interpretation of evidence, not confirmed fact.
- HYPOTHESIS: a proposed idea or possibility.
- UNKNOWN: evidence is missing or insufficient.

Rules:
- FACT needs provenance.
- UNKNOWN stays unknown.
- Conflicting material evidence stays visible.
- Volatile facts such as current metrics, prices, roles or campaigns need a date/freshness context.
- Source count is not the same as evidence quality.
- Do not turn creator information into a brand fact.
- Collaboration ideas must rely on something distinctive about the brand. If the same idea works unchanged for several competitors, it is too generic.
