# Commercial Boundary

Do not invent:
- rates
- usage rights
- whitelisting
- exclusivity
- guarantees
- travel terms
- payment terms
- deadlines or commitments that were not provided

If commercial information is missing, keep the draft non-committal and flag the missing decision.
