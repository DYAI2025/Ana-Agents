# Genericness and Follow-up

## Genericness

The message must depend on brand-specific evidence and the selected collaboration proposition. Merely inserting the brand name is not specificity.

If replacing the brand with a plausible competitor leaves the core pitch unchanged, revise the draft or return NOT_READY.

## Follow-up

Without a new signal, do not invent urgency, traction, events, relationship context or new facts.

A follow-up may:
- restate the existing proposition more concisely
- vary tone or structure
- ask a simple next-step question

It must not manufacture a reason to follow up.
