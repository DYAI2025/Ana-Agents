# Evidence and Framing

Every material factual statement in the outreach must be supported by the upstream context.

- FACT may be stated directly when appropriate.
- SUPPORTED_INFERENCE must be hedged or framed as a question.
- HYPOTHESIS must be hedged or framed as a question.
- UNKNOWN must not be presented externally as fact.

If a material statement cannot be grounded, remove it or return NOT_READY.
