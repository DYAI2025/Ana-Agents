---
name: ana-outreach-compose
description: Evidence-grounded outreach composition for Ana Savu brand partnerships. Use when brand intelligence and contact context already exist and the user needs an outreach strategy, first-touch draft, follow-up, genericness check or semantic review. Do not independently research the brand, discover contacts, mutate CRM, invent commercial terms, authorize send or send mail.
---

# Ana Outreach Compose

## Goal

Turn validated brand intelligence into a specific, credible outreach strategy and draft for Ana.

## Preconditions

Use existing upstream context. At minimum you need:
- a collaboration hypothesis or clear proposition
- contact context
- enough evidence to support any factual statement
- commercial constraints when they matter

If the required context is missing, return UPSTREAM_DATA_MISSING or NOT_READY. Do not browse the brand or fill gaps from memory.

## Workflow

1. Select the strongest evidence-backed collaboration proposition.
2. Select the intended business contact from the provided context.
3. Define the outreach approach and the few facts that actually matter.
4. Apply any known commercial exclusions or boundaries.
5. Draft a concise subject and body.
6. Check every factual brand/creator statement against the provided evidence.
7. Hedge supported inferences and hypotheses; do not present them as confirmed facts.
8. Run a genericness check: if the substantive message still works after swapping in a plausible competitor, revise it or return NOT_READY.
9. Review for clarity, specificity and unnecessary sales language.
10. Return the draft for review. Do not send it.

## Evidence and framing

Read references/evidence-and-framing.md.

## Commercial boundary

Read references/commercial-boundary.md.

## Follow-ups

Read references/genericness-and-followup.md.

## Boundaries

Never independently use web search or web reading to research the brand.

Never perform:
- CRM write/update/delete
- mail send
- send authorization
- lifecycle or policy mutation
- negotiation authority

If information is missing, route the need back to Ana Brand Intel or the CRM Orchestrator instead of researching it yourself.

## Output

Normally return:
- selected proposition
- outreach approach
- subject
- body
- evidence/claim notes when useful
- genericness result
- blockers or unknowns
- next safe action

READY_FOR_HUMAN_REVIEW means the draft is ready to inspect. It does not mean sent or approved.
